1 Paste .env.develop in 
  path = "OpActive_R4B_Automated_Salary_Insights_System_project/R4B_Backend"
  rename as .env
2 Paste .env.containers in 
  path = "OpActive_R4B_Automated_Salary_Insights_System_project/containers"
  rename as .env 
